import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { sendMessage } from "@/lib/openai";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import MessageBubble from "./message-bubble";
import ContactForm from "./contact-form";
import { Loader2 } from "lucide-react";
import { type Conversation } from "@shared/schema";

interface ChatWindowProps {
  conversationId: number;
}

export default function ChatWindow({ conversationId }: ChatWindowProps) {
  const [input, setInput] = useState("");

  const { data: conversation } = useQuery<Conversation>({
    queryKey: ["/api/conversations", conversationId],
  });

  const messageMutation = useMutation({
    mutationFn: (content: string) => sendMessage(conversationId, content),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations", conversationId] });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    messageMutation.mutate(input);
    setInput("");
  };

  if (!conversation) return null;

  return (
    <Card className="h-[600px] flex flex-col">
      <ScrollArea className="flex-1 p-4">
        {conversation.messages.map((message, i) => (
          <MessageBubble key={i} message={message} />
        ))}
        {messageMutation.isPending && (
          <div className="flex justify-center p-2">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        )}
      </ScrollArea>

      {conversation.completed ? (
        <CardContent className="p-4 border-t">
          <p className="text-center text-muted-foreground">
            Merci de votre intérêt ! Nous vous contacterons bientôt.
          </p>
        </CardContent>
      ) : conversation.messages.length >= 6 ? (
        <CardContent className="p-4 border-t">
          <ContactForm conversationId={conversationId} />
        </CardContent>
      ) : (
        <CardFooter className="p-4 border-t">
          <form onSubmit={handleSubmit} className="flex w-full gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Tapez votre message..."
              disabled={messageMutation.isPending}
            />
            <Button type="submit" disabled={messageMutation.isPending}>
              Envoyer
            </Button>
          </form>
        </CardFooter>
      )}
    </Card>
  );
}