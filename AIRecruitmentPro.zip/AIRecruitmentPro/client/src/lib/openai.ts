import { type Message } from "@shared/schema";
import { apiRequest } from "./queryClient";

export async function startConversation() {
  const res = await apiRequest("POST", "/api/conversations");
  return await res.json();
}

export async function sendMessage(conversationId: number, content: string) {
  const res = await apiRequest("POST", `/api/conversations/${conversationId}/messages`, {
    content,
  });
  return await res.json();
}

export async function submitContact(conversationId: number, data: {
  name: string;
  email: string;
  phone: string;
}) {
  const res = await apiRequest("POST", `/api/conversations/${conversationId}/contact`, data);
  return await res.json();
}
