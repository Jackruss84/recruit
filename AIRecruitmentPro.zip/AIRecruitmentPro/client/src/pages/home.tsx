import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { startConversation } from "@/lib/openai";
import { queryClient } from "@/lib/queryClient";
import ChatWindow from "@/components/chat/chat-window";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

export default function Home() {
  const [activeConversation, setActiveConversation] = useState<number | null>(null);
  const { toast } = useToast();

  const startMutation = useMutation({
    mutationFn: startConversation,
    onSuccess: (data) => {
      setActiveConversation(data.id);
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Impossible de démarrer la conversation. Veuillez réessayer plus tard.",
      });
      console.error("Error starting conversation:", error);
    },
  });

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="mb-8">
        <CardContent className="p-6">
          <h2 className="text-2xl font-bold mb-4">Bienvenue dans notre équipe immobilière</h2>
          <p className="text-muted-foreground mb-6">
            Prêt à commencer une carrière passionnante dans l'immobilier ? Notre assistant IA va évaluer votre expérience et vous guider dans le processus de recrutement.
          </p>
          {!activeConversation && (
            <Button
              size="lg"
              onClick={() => startMutation.mutate()}
              disabled={startMutation.isPending}
            >
              {startMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Chargement...
                </>
              ) : (
                "Démarrer la conversation"
              )}
            </Button>
          )}
        </CardContent>
      </Card>

      {activeConversation && (
        <ChatWindow conversationId={activeConversation} />
      )}
    </div>
  );
}