import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { contactFormSchema, type Message } from "@shared/schema";
import OpenAI from "openai";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY environment variable is required");
}

// Add debug logging
console.log("Initializing OpenAI API with key:", process.env.OPENAI_API_KEY.slice(0, 3) + "..." + process.env.OPENAI_API_KEY.slice(-4));

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const RECRUITMENT_PROMPT = `You are a professional real estate agency recruiter. Your goal is to evaluate potential real estate agents through a conversation. Follow these guidelines:

1. Start by introducing yourself and asking for the candidate's name
2. Ask relevant questions about:
   - Previous sales experience
   - Real estate knowledge
   - Motivation and goals
   - Availability and commitment
3. Provide clear information about the role
4. Be professional and courteous
5. End by asking for contact information

Respond in JSON format with: { "message": "your response" }`;

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  app.post("/api/conversations", async (req, res) => {
    try {
      console.log("Starting new conversation...");
      const conversation = await storage.createConversation();

      console.log("Making OpenAI API request...");
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: RECRUITMENT_PROMPT },
        ],
        response_format: { type: "json_object" }
      });

      console.log("OpenAI API response received:", response.choices[0].message);

      const content = response.choices[0].message.content;
      if (!content) throw new Error("No response from OpenAI");

      const message: Message = {
        role: "assistant",
        content: JSON.parse(content).message,
        timestamp: Date.now(),
      };

      await storage.addMessage(conversation.id, message);
      res.json(conversation);
    } catch (error) {
      console.error("Error in /api/conversations:", error);
      // Log more details about the error
      if (error instanceof Error) {
        console.error("Error name:", error.name);
        console.error("Error message:", error.message);
        console.error("Error stack:", error.stack);
      }
      res.status(500).json({ 
        message: "Une erreur est survenue lors de l'initialisation de la conversation",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post("/api/conversations/:id/messages", async (req, res) => {
    try {
      const { id } = req.params;
      const { content } = req.body;

      const conversation = await storage.getConversation(Number(id));
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }

      const userMessage: Message = {
        role: "user",
        content,
        timestamp: Date.now(),
      };
      await storage.addMessage(Number(id), userMessage);

      const messages = conversation.messages as Message[];
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: RECRUITMENT_PROMPT },
          ...messages.map(m => ({
            role: m.role,
            content: m.content
          })),
          { role: "user", content }
        ],
        response_format: { type: "json_object" }
      });

      const assistantContent = response.choices[0].message.content;
      if (!assistantContent) throw new Error("No response from OpenAI");

      const assistantMessage: Message = {
        role: "assistant",
        content: JSON.parse(assistantContent).message,
        timestamp: Date.now(),
      };

      const updated = await storage.addMessage(Number(id), assistantMessage);
      res.json(updated);
    } catch (error) {
      console.error("Error in /api/conversations/:id/messages:", error);
      res.status(500).json({
        message: "Une erreur est survenue lors de l'envoi du message",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post("/api/conversations/:id/contact", async (req, res) => {
    try {
      const { id } = req.params;
      const data = contactFormSchema.parse(req.body);

      const updated = await storage.updateConversation(Number(id), {
        candidateName: data.name,
        candidateEmail: data.email,
        candidatePhone: data.phone,
        completed: true,
      });

      res.json(updated);
    } catch (error) {
      console.error("Error in /api/conversations/:id/contact:", error);
      res.status(500).json({
        message: "Une erreur est survenue lors de l'envoi du formulaire de contact",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/conversations", async (req, res) => {
    try {
      const conversations = await storage.getAllConversations();
      res.json(conversations);
    } catch (error) {
      console.error("Error in GET /api/conversations:", error);
      res.status(500).json({
        message: "Une erreur est survenue lors de la récupération des conversations",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  return httpServer;
}