import { type Conversation, type InsertConversation, type Message } from "@shared/schema";

export interface IStorage {
  createConversation(): Promise<Conversation>;
  getConversation(id: number): Promise<Conversation | undefined>;
  updateConversation(id: number, data: Partial<InsertConversation>): Promise<Conversation>;
  addMessage(id: number, message: Message): Promise<Conversation>;
  getAllConversations(): Promise<Conversation[]>;
}

export class MemStorage implements IStorage {
  private conversations: Map<number, Conversation>;
  private currentId: number;

  constructor() {
    this.conversations = new Map();
    this.currentId = 1;
  }

  async createConversation(): Promise<Conversation> {
    const id = this.currentId++;
    const conversation: Conversation = {
      id,
      messages: [] as Message[],
      candidateName: null,
      candidateEmail: null,
      candidatePhone: null,
      completed: false,
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async updateConversation(
    id: number,
    data: Partial<InsertConversation>,
  ): Promise<Conversation> {
    const conversation = await this.getConversation(id);
    if (!conversation) throw new Error("Conversation not found");

    const updated = { ...conversation, ...data };
    this.conversations.set(id, updated);
    return updated;
  }

  async addMessage(id: number, message: Message): Promise<Conversation> {
    const conversation = await this.getConversation(id);
    if (!conversation) throw new Error("Conversation not found");

    const messages = conversation.messages as Message[];
    const updated = {
      ...conversation,
      messages: [...messages, message],
    };
    this.conversations.set(id, updated);
    return updated;
  }

  async getAllConversations(): Promise<Conversation[]> {
    return Array.from(this.conversations.values());
  }
}

export const storage = new MemStorage();